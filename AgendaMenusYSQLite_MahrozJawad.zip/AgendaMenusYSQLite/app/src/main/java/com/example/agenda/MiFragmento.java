package com.example.agenda;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


import static android.app.Activity.RESULT_OK;

public class MiFragmento extends Fragment implements View.OnClickListener,  View.OnLongClickListener {

    private static final int CODIGO_EDITAR = 2;
    private static final int CODIGO_AÑADIR = 3;
    public RecyclerView recyclerView;
    MiRecyclerAdapter mAdapter;
    private SwipeDetector swipeDetector;
    SQLiteDatabase sqLiteDatabase;
    BDPersonas dbPersonas;
    Cursor miCursor;
    ImageView imagen;
    String imagenPorDefecto;
    private View rootView;
    int pos;
    Persona p;
    Context context;
    public int spanCount;

    public MiFragmento(Context c, Cursor cursor,BDPersonas personas,SQLiteDatabase datos, String imagenPorDefecto, RecyclerView recyclerView, int columnas){
        this.sqLiteDatabase = datos;
        this.imagenPorDefecto = imagenPorDefecto;
        this.recyclerView = recyclerView;
        this.dbPersonas = personas;
        this.spanCount = columnas;
        if(cursor != null) {
            this.miCursor = cursor;
        } else {
            miCursor = sqLiteDatabase.rawQuery("select * from personas", null);
        }
        context = c;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        rootView = inflater.inflate(R.layout.activity_recyclerview, container, false);
        imagen = rootView.findViewById(R.id.imageView);

        FloatingActionButton fab = rootView.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AñadirDatos();
            }
        });

        sqLiteDatabase = dbPersonas.getReadableDatabase();
        if(sqLiteDatabase != null) {
            recyclerView = rootView.findViewById(R.id.recycler);
            CargarRecyclerView();
        }
        return rootView;
    }

    private void CargarRecyclerView() {
        recyclerView.setHasFixedSize(true);
        mAdapter = new MiRecyclerAdapter(((MainActivity)context).ContactoLayout, getContext(), miCursor, sqLiteDatabase );
        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), spanCount));
        mAdapter.SetOnLongClick(this);
        swipeDetector = new SwipeDetector();
        mAdapter.setClickOnView(this);
        mAdapter.SetOnTouchListener(swipeDetector);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public boolean onLongClick(View v) {
        pos = recyclerView.getChildAdapterPosition(v);

        String nombre = SeleccionarCampoSelect("select * from personas where id = " + pos, "nombre");

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setMessage("¿Seguro que quieres eliminar a " + nombre + "?");
        builder.setPositiveButton("ELIMINAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                String[] args = {Integer.toString(pos)};
                sqLiteDatabase.delete("personas", "id=?", args);

                sqLiteDatabase.execSQL("UPDATE personas SET id=id-1 WHERE id > " + pos);

                ((MainActivity)context).CreaFragmento(sqLiteDatabase.rawQuery("select * from personas", null));
            }
        });
        builder.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.create().show();
        return true;
    }

    @Override
    public void onClick(View v) {
        pos = recyclerView.getChildAdapterPosition(v);
        
        final String telefono = SeleccionarCampoSelect("select * from personas where id = " + pos, "telefono");
        String nombre = SeleccionarCampoSelect("select * from personas where id = " + pos, "nombre");
        final String correo = SeleccionarCampoSelect("select * from personas where id = " + pos, "correo");
        
        if (swipeDetector.swipeDetected()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            switch (swipeDetector.getAction()) {
                case LR:
                    builder.setMessage("¿Estas seguro que quieres llamar a " + nombre + "?");
                    builder.setPositiveButton("LLAMAR", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("telefono: " + telefono));
                            if (intent.resolveActivity(getContext().getPackageManager()) != null) {
                                startActivity(intent);
                            }
                        }
                    });
                    builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    builder.create().show();
                    break;
                case RL:
                    builder = new AlertDialog.Builder(getContext());
                    builder.setMessage("¿Estas seguro que quieres enviar mensaje a " + nombre + "?");
                    builder.setPositiveButton("enviar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(Intent.ACTION_SENDTO);
                            intent.setData(Uri.fromParts("mailto", correo, null));
                            Intent chooser = Intent.createChooser(intent, "Enviar mensaje...");
                            startActivity(chooser);
                        }
                    });
                    builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    builder.create().show();
                    break;
            }
        } else {
            EditarDatos();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case CODIGO_EDITAR:
                if (resultCode == RESULT_OK) {
                    p = data.getParcelableExtra("PersonaEditado");
                    if(p != null){

                        ContentValues valores = new ContentValues();
                        valores.put("nombre", p.getNombre());
                        valores.put("apellidos", p.getApellidos());
                        valores.put("telefono", p.getTelefono());
                        valores.put("correo", p.getCorreo());
                        valores.put("imagenString", p.getImagenString());
                        valores.put("etiqueta", p.getEtiqueta()[0] +", "+p.getEtiqueta()[1]+", "+p.getEtiqueta()[2]);
                        String[] args = {Integer.toString(pos)};
                        sqLiteDatabase.update("personas",valores, "id=?", args);
                    }
                }
                break;
            case CODIGO_AÑADIR:
                if (resultCode == RESULT_OK) {
                    p = data.getParcelableExtra("PersonaEditado");
                    if(p != null){
                        miCursor = sqLiteDatabase.rawQuery("select * from personas", null);
                        ContentValues valores = new ContentValues();
                        valores.put("id", miCursor.getCount());
                        valores.put("nombre", p.getNombre());
                        valores.put("apellidos", p.getApellidos());
                        valores.put("telefono", p.getTelefono());
                        valores.put("correo", p.getCorreo());
                        valores.put("imagenString", p.getImagenString());
                        valores.put("etiqueta", p.getEtiqueta()[0] +", "+p.getEtiqueta()[1]+", "+p.getEtiqueta()[2]);
                        String[] args = {Integer.toString(pos)};
                        sqLiteDatabase.insert("personas",null, valores);
                    }
                }
                break;
        }
        ((MainActivity)context).CreaFragmento(sqLiteDatabase.rawQuery("select * from personas", null));
    }
    private void EditarDatos() {
        Intent intent = new Intent(getContext(), EditarContacto.class);
        String sentencia = "SELECT * FROM personas WHERE id=" + pos;
        String nombre = SeleccionarCampoSelect(sentencia, "nombre");
        String apellidos = SeleccionarCampoSelect(sentencia, "apellidos");
        String telefono = SeleccionarCampoSelect(sentencia, "telefono");
        String correo = SeleccionarCampoSelect(sentencia, "correo");
        String imagenString = SeleccionarCampoSelect(sentencia, "imagenString");
        String etiquetaDesdeCampo = SeleccionarCampoSelect(sentencia, "etiqueta");

        String[] etiqueta = etiquetaDesdeCampo.split(",");

        Persona p = new Persona(nombre, apellidos, telefono, correo, imagenString, etiqueta);

        intent.putExtra("DatoPersona", p);
        startActivityForResult(intent,CODIGO_EDITAR);
    }
    private void AñadirDatos() {
        Intent intent = new Intent(getContext(), EditarContacto.class);
        Persona p = null;
        intent.putExtra("DatoPersona", p);
        startActivityForResult(intent,CODIGO_AÑADIR);
    }


    public String SeleccionarCampoSelect(String sentencia, String campo) {
        sqLiteDatabase = dbPersonas.getReadableDatabase();
        String campoString = "";
        if(sqLiteDatabase != null) {
            Cursor cursor = sqLiteDatabase.rawQuery(sentencia, null);
            if(cursor != null) {
                cursor.moveToFirst();
                campoString = cursor.getString(cursor.getColumnIndex(campo));
            }
        }
        return campoString;
    }

}
