package com.example.agenda;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import com.google.android.material.navigation.NavigationView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Base64;import android.view.Menu;
import android.view.MenuItem;
import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    BDPersonas personas;
    SQLiteDatabase dbPersonas;
    int ContactoLayout;

    String imagenPorDefecto;
    MiFragmento fragmentLista;
    public RecyclerView recyclerView;
    private int spanColumnas;
    private int navigationItemSelectedId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_lateral);
        spanColumnas = 1;
        ContactoLayout = R.layout.contacto;

        personas = new BDPersonas(getBaseContext(), "BDPERSONAS", null, 1);
        dbPersonas = personas.getWritableDatabase();

        imagenPorDefecto = BitmapAString(Bitmap.createScaledBitmap(BitmapFactory.decodeResource(this.getResources(), R.drawable.pordefecto_imagen),100,100,true));
        //insertarDatosCodigo();

        CreaFragmento(null);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

    }

    private void insertarDatosCodigo() {
        if(dbPersonas != null){
            ContentValues valores = new ContentValues();
            valores.put("id", 0);
            valores.put("nombre", "Mahroz");
            valores.put("apellidos", "Jawad");
            valores.put("telefono", "631637415");
            valores.put("Correo", "mahroz@mahroz.com");
            valores.put("imagenString", imagenPorDefecto);
            valores.put("etiqueta", "Trabajo");
            dbPersonas.insert("personas", null, valores);
        }
    }

    public void CreaFragmento(Cursor cursor) {
        BooraFragmento();
        fragmentLista = new MiFragmento(this,cursor, personas,dbPersonas, imagenPorDefecto, recyclerView, spanColumnas);
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.fragment_container, fragmentLista);
        fragmentTransaction.commit();
    }

    private void BooraFragmento() {
        if(fragmentLista != null) {
            getSupportFragmentManager().beginTransaction().
                    remove(getSupportFragmentManager().findFragmentById(R.id.fragment_container)).commit();
        }
    }

    public static String BitmapAString(Bitmap imagen) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        imagen.compress(Bitmap.CompressFormat.PNG, 90, stream);
        byte[] byte_arr = stream.toByteArray();
        String image_str = Base64.encodeToString(byte_arr, Base64.DEFAULT);
        return image_str;
    }
    public static Bitmap StringABitmap(String imagen) {
        byte[] decodedString = Base64.decode(imagen, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        //noinspection SimplifiableIfStatement
        if (id == R.id.Grid) {
            if(spanColumnas == 3) {
                spanColumnas = 1;
                ContactoLayout = R.layout.contacto;
            }
            else {
                spanColumnas = 3;
                ContactoLayout = R.layout.contacto_grid;
            }
            Filtrar(navigationItemSelectedId);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        // Handle navigation view item clicks here.
        int id = menuItem.getItemId();
        navigationItemSelectedId = id;

        Filtrar(id);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void Filtrar(int id) {
        Cursor cur = null;
        switch (id){
            case R.id.nav_todos:
                break;
            case R.id.nav_amigos:
                cur = dbPersonas.rawQuery("SELECT * FROM personas where etiqueta LIKE '%"+"Amigos"+"%'",null);
                break;
            case R.id.nav_familia:
                cur = dbPersonas.rawQuery("SELECT * FROM personas where etiqueta LIKE '%"+"Familia"+"%'",null);
                break;
            case R.id.nav_trabajo:
                cur = dbPersonas.rawQuery("SELECT * FROM personas where etiqueta LIKE '%"+"Trabajo"+"%'",null);
                break;
        }
        CreaFragmento(cur);
    }
}
