package com.example.agenda;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

public class MiRecyclerAdapter extends CursorRecyclerAdapter implements View.OnClickListener, View.OnTouchListener, View.OnLongClickListener  {

    private SQLiteDatabase sqLiteDatabase;
    private int mLayout;
    private Context c;
    View.OnClickListener listener;
    View.OnLongClickListener longClickListener;
    View.OnTouchListener onTouchListener;

    public MiRecyclerAdapter(int layout, Context c, Cursor cursor, SQLiteDatabase sqLiteDatabase) {
        super(c, cursor);
        this.sqLiteDatabase = sqLiteDatabase;
        mLayout = layout;
        this.c = c;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(mLayout, parent, false);
        view.setOnTouchListener(this);
        view.setOnClickListener(this);
        view.setOnLongClickListener(this);
        return new Holder(view,c);
    }
    public  void setClickOnView(View.OnClickListener listener) {
        if(listener!=null) this.listener= listener;
    }
    @Override
    public void onClick(View view) {
        if(listener!=null) listener.onClick(view);
    }
    public void SetOnTouchListener(View.OnTouchListener touchListener) {
        if(touchListener!=null) onTouchListener = touchListener;
    }
    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if(onTouchListener != null) {
            onTouchListener.onTouch(view, motionEvent);
        }
        return false;
    }

    public void  SetOnLongClick(View.OnLongClickListener longClickListener) {
        if(longClickListener != null) {
            this.longClickListener = longClickListener;
        }
    }
    @Override
    public boolean onLongClick(View view) {
        if(longClickListener!=null) longClickListener.onLongClick(view);
        return false;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, Cursor cursor, int position) {

        int pos = position;

        cursor = sqLiteDatabase.rawQuery("SELECT * FROM personas", null);
        Cursor cur = sqLiteDatabase.rawQuery("SELECT * FROM personas where id=" + position, null);

        cur.moveToFirst();
        if(position < cursor.getCount()) {
            String nombre = cur.getString(cur.getColumnIndex("nombre"));
            String apellidos = cur.getString(cur.getColumnIndex("apellidos"));
            String telefono = cur.getString(cur.getColumnIndex("telefono"));
            String correo = cur.getString(cur.getColumnIndex("correo"));
            String imagenString = cur.getString(cur.getColumnIndex("imagenString"));
            String etiquetaDesdeCampo = cur.getString(cur.getColumnIndex("etiqueta"));

            String[] etiqueta = etiquetaDesdeCampo.split(",");

            Persona p = new Persona(nombre, apellidos, telefono, correo, imagenString, etiqueta);
            ((Holder)holder).bind(p);
        }
    }
}
