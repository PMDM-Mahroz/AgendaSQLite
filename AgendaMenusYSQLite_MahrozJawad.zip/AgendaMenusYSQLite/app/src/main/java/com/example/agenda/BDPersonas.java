package com.example.agenda;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BDPersonas extends SQLiteOpenHelper {

    String sentencia = "create table if not exists personas (id INTEGER PRIMARY KEY NOT NULL, nombre TEXT, apellidos TEXT, telefono TEXT, correo TEXT, imagenString TEXT, etiqueta TEXT)";

    public BDPersonas(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sentencia);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
