package com.example.agenda;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;


public abstract class CursorRecyclerAdapter extends RecyclerView.Adapter {

    Cursor mCursor;
    Context c;
    Holder h;

    public CursorRecyclerAdapter(Context c, Cursor cursor){
        this.c = c;
        mCursor = cursor;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contacto, parent, false);
        h = new Holder(view,c);
        return h;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if(mCursor==null) {
            throw new IllegalStateException("Error, Cursor Vacío");
        }
        if(!mCursor.moveToPosition(position)) {
            throw new IllegalStateException("Error, no se puede encontrar la posicion: " + position);
        }
        onBindViewHolder(holder, mCursor, position);
    }

    public abstract void onBindViewHolder(RecyclerView.ViewHolder holder, Cursor cursor, int position);

    @Override
    public int getItemCount() {
        if(mCursor != null) {
            return  mCursor.getCount();
        }
        else
            return 0;
    }

    @Override
    public long getItemId(int position) {
        if(hasStableIds() && mCursor != null) {
            if(mCursor.moveToPosition(position)) {
                mCursor.getLong(mCursor.getColumnIndexOrThrow("id"));
            }
        }
        return RecyclerView.NO_ID;
    }

}
